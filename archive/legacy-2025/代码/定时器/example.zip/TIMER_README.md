# RDFW 实时计时器使用指南

## 概述

我已经在 `rdfw.cpp` 中实现了一个实时计时器功能，可以在任务执行过程中每隔0.1秒显示一次当前时间，并在超时时自动执行紧急停止程序，让机器人停止任务并寻找安全位置。

## 功能特性

- ✅ 实时计时，精确到毫秒
- ✅ 每隔0.1秒自动显示时间
- ✅ 超时自动触发紧急停止
- ✅ 自动寻找安全位置
- ✅ 紧急关闭程序
- ✅ 线程安全，使用原子操作
- ✅ 可自定义计时器名称和超时时间
- ✅ 获取已用时间和剩余时间
- ✅ 自动资源管理

## 主要组件

### 1. RealTimeTimer 类
- 独立的计时器类，每隔0.1秒显示时间
- 支持超时机制和回调函数
- 使用 `std::thread` 和 `std::chrono` 实现
- 线程安全，支持启动、停止、重置操作

### 2. RDFW 类集成
- 在 RDFW 类中添加了计时器相关方法
- 自动在关键位置启动和停止计时器
- 提供便捷的计时器管理接口
- 集成紧急停止和安全位置功能

### 3. 紧急停止系统
- 超时自动触发紧急停止
- 智能寻找安全位置
- 完整的紧急关闭程序
- 任务执行暂停机制

## 使用方法

### 基本使用

```cpp
// 1. 启动计时器（每隔0.1秒显示时间，30秒后自动停止）
startTaskTimer("MyTimer", 30000);

// 2. 启动默认名称的计时器（使用默认超时时间）
startTaskTimer();  // 使用默认名称"TaskTimer"和默认超时时间

// 3. 获取已用时间
long long elapsed = getTaskElapsedTime();    // 已用时间（毫秒）

// 4. 检查计时器是否运行
bool isRunning = isTaskTimerRunning();

// 5. 检查是否超时
bool isTimeout = isTaskTimeout();

// 6. 停止计时器
stopTaskTimer();
```

### 在代码中的集成点

计时器已经自动集成到以下关键位置：

1. **Plan() 方法开始**：自动启动计时器
2. **ExecuteMainTaskLoop()**：在任务循环中显示进度信息
3. **Fini() 方法**：自动停止计时器

### 计时器输出示例

计时器会在后台线程中每隔0.1秒显示一次时间，并在超时时执行紧急停止：

```
#(RDFW_TaskTimer): Timer started
#(RDFW_TaskTimer): Elapsed time: 100ms
#(RDFW_TaskTimer): Elapsed time: 200ms
#(RDFW_TaskTimer): Elapsed time: 300ms
#(RDFW_TaskTimer): Elapsed time: 400ms
...
#(RDFW_TaskTimer): Elapsed time: 30000ms
#(RDFW_TaskTimer): TIMEOUT REACHED! Executing emergency stop...

#(RDFW): ========== EMERGENCY STOP ACTIVATED ==========
#(RDFW): Time limit reached! Stopping all tasks and finding safe location...
#(RDFW): Stopping current task execution...
#(RDFW): Dropping held object: 1
#(RDFW): Searching for safe location...
#(RDFW): Current location 0 is considered safe
#(RDFW): Moving to safe location: 0
#(RDFW): Successfully moved to safe location 0
#(RDFW): Performing emergency shutdown procedures...
#(RDFW): Emergency shutdown completed at location 0
#(RDFW): Robot is now in safe standby mode
#(RDFW): Emergency stop completed. Robot is now in safe mode.
#(RDFW): ================================================
```

## 配置选项

### 计时器名称和超时时间
```cpp
startTaskTimer("CustomTimerName", 60000);  // 自定义计时器名称，60秒超时
```

### 默认超时时间
```cpp
int default_timeout_ms = 30000;  // 默认30秒超时
```

### 启用/禁用计时器
```cpp
bool timer_enabled = true;  // 计时器启用状态
```

## 示例场景

### 场景1：任务执行时间监控和紧急停止
```cpp
// 在任务执行前启动计时器（30秒超时）
startTaskTimer("TaskExecution", 30000);

// 执行任务
for (auto& task : tasks) {
    // 检查是否进入紧急模式
    if (isTaskTimeout()) {
        cout << "任务超时，紧急停止已激活" << endl;
        break;
    }
    // 计时器会自动每隔0.1秒显示时间
    // 执行任务...
}

// 停止计时器
stopTaskTimer();
```

### 场景2：性能监控
```cpp
startTaskTimer("PerformanceMonitor", 60000);  // 60秒超时
// 执行一些操作...
long long elapsed = getTaskElapsedTime();
cout << "操作耗时: " << elapsed << "ms" << endl;
```

### 场景3：多计时器使用
```cpp
// 启动多个计时器
startTaskTimer("MainTask", 30000);  // 主任务30秒超时
// 执行主任务...

startTaskTimer("SubTask", 15000);   // 子任务15秒超时
// 执行子任务...

stopTaskTimer();  // 停止当前计时器
```

### 场景4：紧急停止测试
```cpp
// 启动短时间计时器进行测试
startTaskTimer("EmergencyTest", 5000);  // 5秒超时测试

// 模拟长时间任务
while (true) {
    if (isTaskTimeout()) {
        cout << "紧急停止已激活，机器人已移动到安全位置" << endl;
        break;
    }
    // 执行任务...
}
```

## 注意事项

1. **线程安全**：计时器使用原子操作，线程安全
2. **资源管理**：计时器会在析构时自动清理资源
3. **性能影响**：计时器每100ms检查一次，对性能影响很小
4. **显示精度**：时间显示精度为100ms（检查间隔）
5. **后台运行**：计时器在后台线程中运行，不会阻塞主线程
6. **紧急停止**：超时后会自动执行紧急停止程序，确保机器人安全
7. **安全位置**：系统会自动寻找最佳安全位置并移动机器人
8. **任务暂停**：紧急模式下会暂停所有任务执行

## 编译要求

确保您的项目包含以下头文件：
- `<chrono>`
- `<thread>`
- `<functional>`
- `<atomic>`
- `<memory>`

## 总结

这个实时计时器功能为您的RDFW系统提供了强大的时间监控和安全保护能力，让您能够：
- 实时了解任务执行进度
- 监控系统性能
- 自动超时保护
- 紧急停止和安全位置管理
- 调试和优化代码
- 提供用户友好的时间反馈

计时器已经集成到您的代码中，默认30秒超时，您可以根据需要调整超时时间。系统会在超时时自动执行紧急停止程序，确保机器人安全。

## 故障排除

### 常见问题

1. **编译错误**：确保包含了必要的头文件
2. **计时器不工作**：检查 `timer_enabled` 状态
3. **时间不显示**：确保计时器已启动且正在运行

### 调试信息

计时器会输出详细的调试信息：
```
#(RDFW): Task timer started with name: RDFW_TaskTimer
#(RDFW_TaskTimer): Timer started
#(RDFW_TaskTimer): Elapsed time: 100ms
#(RDFW_TaskTimer): Elapsed time: 200ms
#(RDFW): Task timer stopped during cleanup
#(RDFW_TaskTimer): Timer stopped. Total elapsed time: 5000ms
```

## 扩展功能

您可以根据需要扩展计时器功能：

1. **多计时器支持**：为不同任务创建多个计时器
2. **时间统计**：记录每个任务的执行时间
3. **性能分析**：分析任务执行效率
4. **自定义显示格式**：修改时间显示格式
5. **日志记录**：将时间信息记录到日志文件

## 联系信息

如有问题或建议，请查看代码注释或联系开发者。
