/*
 * 简单计时器测试
 * 展示计时器每隔0.1秒显示时间的功能
 */

#include "rdfw.hpp"
#include <iostream>
#include <chrono>
#include <thread>

using namespace _home;

int main() {
    std::cout << "=== 简单计时器测试 ===" << std::endl;
    std::cout << "这个测试将展示计时器每隔0.1秒显示时间的功能" << std::endl;
    std::cout << "测试将持续3秒..." << std::endl;
    std::cout << std::endl;
    
    // 创建RDFW实例
    RDFW rdfw;
    
    // 启动计时器
    rdfw.startTaskTimer("TestTimer");
    
    // 等待3秒，让计时器显示时间
    std::this_thread::sleep_for(std::chrono::milliseconds(3000));
    
    // 停止计时器
    rdfw.stopTaskTimer();
    
    std::cout << std::endl;
    std::cout << "=== 测试完成 ===" << std::endl;
    std::cout << "您应该看到计时器每隔0.1秒显示一次时间" << std::endl;
    
    return 0;
}

/*
 * 预期输出：
 * 
 * === 简单计时器测试 ===
 * 这个测试将展示计时器每隔0.1秒显示时间的功能
 * 测试将持续3秒...
 * 
 * #(RDFW): Task timer started with name: TestTimer
 * #(TestTimer): Timer started
 * #(TestTimer): Elapsed time: 100ms
 * #(TestTimer): Elapsed time: 200ms
 * #(TestTimer): Elapsed time: 300ms
 * #(TestTimer): Elapsed time: 400ms
 * #(TestTimer): Elapsed time: 500ms
 * #(TestTimer): Elapsed time: 600ms
 * #(TestTimer): Elapsed time: 700ms
 * #(TestTimer): Elapsed time: 800ms
 * #(TestTimer): Elapsed time: 900ms
 * #(TestTimer): Elapsed time: 1000ms
 * #(TestTimer): Elapsed time: 1100ms
 * #(TestTimer): Elapsed time: 1200ms
 * #(TestTimer): Elapsed time: 1300ms
 * #(TestTimer): Elapsed time: 1400ms
 * #(TestTimer): Elapsed time: 1500ms
 * #(TestTimer): Elapsed time: 1600ms
 * #(TestTimer): Elapsed time: 1700ms
 * #(TestTimer): Elapsed time: 1800ms
 * #(TestTimer): Elapsed time: 1900ms
 * #(TestTimer): Elapsed time: 2000ms
 * #(TestTimer): Elapsed time: 2100ms
 * #(TestTimer): Elapsed time: 2200ms
 * #(TestTimer): Elapsed time: 2300ms
 * #(TestTimer): Elapsed time: 2400ms
 * #(TestTimer): Elapsed time: 2500ms
 * #(TestTimer): Elapsed time: 2600ms
 * #(TestTimer): Elapsed time: 2700ms
 * #(TestTimer): Elapsed time: 2800ms
 * #(TestTimer): Elapsed time: 2900ms
 * #(TestTimer): Elapsed time: 3000ms
 * #(TestTimer): Timer stopped. Total elapsed time: 3000ms
 * 
 * === 测试完成 ===
 * 您应该看到计时器每隔0.1秒显示一次时间
 */


