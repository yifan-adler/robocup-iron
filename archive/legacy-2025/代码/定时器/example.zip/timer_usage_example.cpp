/*
 * 计时器使用示例
 * 展示如何在RDFW类中使用实时计时器（每隔0.1秒显示时间）
 */

#include "rdfw.hpp"
#include <iostream>
#include <chrono>
#include <thread>

using namespace _home;

int main() {
    // 创建RDFW实例
    RDFW rdfw;
    
    std::cout << "=== 计时器使用示例 ===" << std::endl;
    
    // 示例1：启动计时器（每隔0.1秒显示时间，30秒后自动停止）
    std::cout << "\n1. 启动计时器（每隔0.1秒显示时间，30秒后自动停止）" << std::endl;
    rdfw.startTaskTimer("ExampleTimer", 30000);  // 启动计时器，30秒后自动停止并寻找安全位置
    
    // 模拟一些工作
    std::cout << "模拟工作2秒..." << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(2000));
    
    // 检查计时器状态
    std::cout << "当前已用时间: " << rdfw.getTaskElapsedTime() << "ms" << std::endl;
    std::cout << "计时器是否运行: " << (rdfw.isTaskTimerRunning() ? "是" : "否") << std::endl;
    
    // 示例2：重新启动计时器（10秒超时）
    std::cout << "\n2. 重新启动计时器（10秒超时）" << std::endl;
    rdfw.startTaskTimer("NewTimer", 10000);  // 重新启动计时器，10秒后自动停止
    
    // 模拟更多工作
    std::cout << "模拟工作1.5秒..." << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(1500));
    
    std::cout << "当前已用时间: " << rdfw.getTaskElapsedTime() << "ms" << std::endl;
    
    // 示例3：停止计时器
    std::cout << "\n3. 停止计时器" << std::endl;
    rdfw.stopTaskTimer();
    std::cout << "计时器已停止" << std::endl;
    
    std::cout << "\n=== 示例完成 ===" << std::endl;
    std::cout << "注意：计时器会在后台线程中每隔0.1秒显示一次时间" << std::endl;
    
    return 0;
}

/*
 * 在您的代码中使用计时器的步骤：
 * 
 * 1. 在Plan()方法开始时启动计时器：
 *    startTaskTimer("TaskTimer", 30000);  // 启动计时器，30秒后自动停止并寻找安全位置
 * 
 * 2. 计时器会自动在后台显示时间，并在超时时执行紧急停止
 * 
 * 3. 在Fini()方法中停止计时器：
 *    stopTaskTimer();
 * 
 * 4. 可选：获取计时器状态：
 *    long long elapsed = getTaskElapsedTime();
 *    bool isRunning = isTaskTimerRunning();
 *    bool isTimeout = isTaskTimeout();
 * 
 * 5. 计时器输出示例：
 *    #(TaskTimer): Timer started
 *    #(TaskTimer): Elapsed time: 100ms
 *    #(TaskTimer): Elapsed time: 200ms
 *    #(TaskTimer): Elapsed time: 300ms
 *    ...
 *    #(TaskTimer): TIMEOUT REACHED! Executing emergency stop...
 *    #(RDFW): ========== EMERGENCY STOP ACTIVATED ==========
 *    #(RDFW): Time limit reached! Stopping all tasks and finding safe location...
 *    #(RDFW): Emergency stop completed. Robot is now in safe mode.
 */
